package com.niit.SkillMappingBackEnd.TestCase;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.niit.SkillMappingBackEnd.Entity.Skill;
import com.niit.SkillMappingBackEnd.Repository.SkillsDaoImp;


public class SkillsTest {
	private static SkillsDaoImp skillDao = new SkillsDaoImp();
	private Skill skill = new Skill();
	
	@BeforeClass
	public static void init() {
		skillDao = new SkillsDaoImp();
	}
	@Ignore

	@Test
	public void testInsertUser() {
		boolean flag;
		skill = new Skill();
	    skill.setEmpId(110);
		skill.setId(16);
		skill.setSkillname("java");
		skill.setCertification("certifiaction");
		skill.setExperince("9");
		
		
		
		flag = skillDao.insertUser(skill);
		assertEquals("Failed to insert userdetails!", true, flag);
		
	}

	
@Ignore
	@Test
	public void testgetskillById() {
		skill = skillDao.getskillbyId(116);
		assertEquals("Failed to get User !", "java", skill.getSkillname());
	}

 @Ignore

	@Test
	public void testUpdateUser() {

	skill = skillDao.getskillbyId(118);

		skill.setSkillname("java");

		boolean flag =skillDao.updateSkills(skill);
		assertEquals("Failed to update userdetails!", true, flag);
	}

	@Ignore
	@Test
	public void testDeleteUser() {

		boolean flag = skillDao.deleteUser(118);
		assertEquals("Failed to delete userdetails!", true, flag);
	}
	//@Ignore
	@Test
	public void  getUserByskillname() {
	List<Skill> list=skillDao. getUserByskillname("Java");
	assertEquals("no user present with that skill!",1,list.size());
	}
}	