package com.niit.SkillMappingBackEnd.Entity;


	import java.util.regex.Matcher;
	import java.util.regex.Pattern;





	public class Users {

		private int empId;
		private String name;
		private String dob;
		private String gender;
		private String Address;
		private String qualification;
		private String EmailId;
		private String password;
		private String contactnumber;
		private String Department;
		private String supervicer;
		private String Role;
		private String Authentification;
		
		
		
		public int getEmpId() {
			return empId;
		}
		public void setEmpId(int empId) {
			this.empId = empId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getDob() {
			return dob;
		}
		public void setDob(String dob) {
			this.dob = dob;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getAddress() {
			return Address;
		}
		public void setAddress(String address) {
			Address = address;
		}
		public String getQualification() {
			return qualification;
		}
		public void setQualification(String qualification) {
			this.qualification = qualification;
		}
		public String getEmailId() {
			return EmailId;
		}
		public void setEmailId(String emailId) {
			EmailId = emailId;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getContactnumber() {
			return contactnumber;
		}
		public void setContactnumber(String contactnumber) {
			this.contactnumber = contactnumber;
		}
		public String getDepartment() {
			return Department;
		}
		public void setDepartment(String department) {
			Department = department;
		}
		public String getSupervicer() {
			return supervicer;
		}
		public void setSupervicer(String supervicer) {
			this.supervicer = supervicer;
		}
		public String getRole() {
			return Role;
		}
		public void setRole(String role) {
			Role = role;
		}
		public String getAuthentification() {
			return Authentification;
		}
		public void setAuthentification(String authentification) {
			Authentification = authentification;
		}
		
	}



